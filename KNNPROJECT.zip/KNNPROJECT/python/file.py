
#import io
#my_file_handle=open("movies.csv")
#my_file_handle.read()

my_file=open("movies.csv","r",encoding="utf8")
titles=my_file.readline()


#Use print to print the line else will remain in buffer and replaced by next statement
#print(my_file.readline())
# outputs first two characters of next line
#print(my_file.readline(2))


def main():
    f=open("data.txt","w+")
    #i=1
    #for i in range(2):
    #while True:
    for i in range(9740):     
     content=my_file.readline()
     columns=content.split(',')
     #j=2
     #for j in columns:       
     #print(columns)   
      #f.write(1)
     f.write("\n") 
     f.write(str(i))
     f.write(",")
   
     f.write(columns[1])
    
     genre=columns[2]
     
     types=columns[2].split('|')
     
     print(types)
     
     
     #j=types.index
     #print(j)
     #for s in range(j):
     if  "Action" in types:
       f.write(',1')
     else:
       f.write(',0')  
     if "Adventure" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Children" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Crime" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Thriller" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Romance" in types:
        f.write(',1')
     else:
        f.write(',0')


     if "Comedy" in types:
        f.write(',1')
     else:
      f.write(',0')


     if "Horror" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Animation" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Fantasy" in types:
        f.write(',1')  
     else:
        f.write(',0')


     if "Drama" in types:
        f.write(',1')  
     else:
        f.write(',0')


   
     if "Mystery" in types:
        f.write(',1')  
     else:
        f.write(',0')


    
     if "Sci-Fi" in types:
        f.write(',1')  
     else:
        f.write(',0')

    
     if "War" in types:
        f.write(',1')  
     else:
        f.write(',0')


    
     if "Musical" in types:
        f.write(',1')  
     else:
        f.write(',0')

    
     if "Drama" in types:
        f.write(',1')  
     else:
        f.write(',0')


     
     if "Documentary" in types:
        f.write(',1')  
     else:
        f.write(',0')      

          
            
   

      
      
 
         

          

        
       


           

       

       
     
     #checkGenre(genre)
   
        #print(content)
         #f.write(columns.index[1])
        #genre(columns[1])
        #i=i+1
    f.close

#def checkGenre(genre):
    #file=open("new.txt","a")
    #types=genre.split('|')
    #if types =="Action":
       #file.write(',1')
    #else:      
       #file.write(',0')
   
       
      
        
    

    
    



if __name__=="__main__":
    main()
